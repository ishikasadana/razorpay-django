# coffee_full_project
Complete Cold Coffee project for how to integrate Razorpay with Django
