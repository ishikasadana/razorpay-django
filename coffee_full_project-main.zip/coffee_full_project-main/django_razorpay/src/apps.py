from django.apps import AppConfig


class SrcConfig(AppConfig):
    name = 'src'
